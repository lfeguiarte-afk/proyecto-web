//Array(Arreglo) para las imagenes, aquí van a poner las imagenes//
// de cada uno ( ES INDIVIDUAL) //

//fotos de Unsplash (ajustadas con w=400&h=300&fit=crop)//

const imagenes = [
  "https://i.pinimg.com/736x/14/ad/09/14ad094e7f5e0e3ce6c6d5274e077c55.jpg",
  "https://i.pinimg.com/736x/84/4f/5a/844f5a9325efc537a29b36acbd2dc3f6.jpg",
  "https://i.pinimg.com/736x/d1/ea/c0/d1eac04a35dc0624534a23baab688717.jpg",
  "https://i.pinimg.com/736x/ce/7c/83/ce7c832a02047ddfdc2fd66ef9f308c4.jpg",
  "https://i.pinimg.com/736x/93/8e/a9/938ea97916815d74c03bbd9453b4fe7f.jpg",
  "https://i.pinimg.com/736x/1b/60/5a/1b605a83458333f263e5dc2115cc30c6.jpg"
];

//Seleccion de elementos // 

const boton = document.getElementById("btn-cambiar");
const imagenCard = document.getElementById("card-img");
const textoCard = document.getElementById("card-text");

//contador de las imagenes//

let indice = 0;

//evento del click//
boton.addEventListener("click", () => {
 
 //lo siguiente es para que avance la foto //
  indice++;

//el siguiente if es para que cuando llegue al final se regrese al inicio//
  
  if (indice >= imagenes.length) {
    indice = 0;
  }
      // Cambiar imagen y texto //
imagenCard.src = imagenes[indice];
  textoCard.textContent = `Mostrando imagen ${indice + 1} de ${imagenes.length}`;
});
     