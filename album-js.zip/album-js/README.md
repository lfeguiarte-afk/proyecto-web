# album JS

A Pen created on CodePen.

Original URL: [https://codepen.io/LUIS-FERNANDO-EGUIARTESEGURA/pen/pvjBmWO](https://codepen.io/LUIS-FERNANDO-EGUIARTESEGURA/pen/pvjBmWO).

